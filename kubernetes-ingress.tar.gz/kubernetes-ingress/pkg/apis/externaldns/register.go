package externaldns

const (
	// GroupName the name of the group used by kubernetes.
	GroupName = "externaldns.nginx.org"
)
