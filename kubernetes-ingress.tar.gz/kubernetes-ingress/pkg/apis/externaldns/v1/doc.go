// +k8s:deepcopy-gen=package
// +groupName=externaldns.nginx.org

// Package v1 is the v1 version of the API.
package v1
