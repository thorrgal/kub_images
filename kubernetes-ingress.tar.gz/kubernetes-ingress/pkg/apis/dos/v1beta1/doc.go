// +k8s:deepcopy-gen=package
// +groupName=appprotectdos.f5.com

// Package v1beta1 is the v1beta1 version of the API.
package v1beta1
