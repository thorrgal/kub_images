---
title: Ingress Resources
description:
weight: 1500
menu:
  docs:
    parent: NGINX Ingress Controller
---
